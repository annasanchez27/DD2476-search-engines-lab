#!/bin/sh
java -cp classes -Xmx1g ir.Engine -d /Users/annasanchezespunyes/Documents/KTH/Search_Engines/davisWiki -l ir20.png -p patterns.txt